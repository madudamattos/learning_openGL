#include "tiro.h"
#include <math.h>
#define DISTANCIA_MAX 500

void Tiro::DesenhaCirc(GLint radius, GLfloat R, GLfloat G, GLfloat B)
{
    glPointSize(2.0f); 
    glColor3f(R, G, B); 
    glBegin(GL_LINE_LOOP);
        for(int ang=0; ang<360; ang+=20)
        {
            float rad = ang * M_PI / 180.0f; // converte para radianos
            float x = radius * cos(rad);
            float y = radius * sin(rad);

            glVertex3f(x, y, 0.0f); // ponto no círculo
        }
    glEnd();
}

void Tiro::DesenhaTiro(GLfloat x, GLfloat y)
{
    glPushMatrix();
    glTranslatef(x,y,0);
    DesenhaCirc(radiusTiro, 1, 1, 1);
    glPopMatrix();  
}

void Tiro::Move()
{

}

bool Tiro::Valido()
{
    if(gX > DISTANCIA_MAX || gY > DISTANCIA_MAX)
        return false
    return true
}
